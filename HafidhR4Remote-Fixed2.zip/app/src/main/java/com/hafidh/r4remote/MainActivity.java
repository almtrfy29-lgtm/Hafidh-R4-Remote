package com.hafidh.r4remote;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.hardware.ConsumerIrManager;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private ConsumerIrManager ir;
    private TextView status;
    private final int freq = 38000;

    private final Map<String,Integer> code = new HashMap<String,Integer>() {{
        put("POWER",0x45); put("MUTE",0x43); put("VOL+",0x62); put("VOL-",0x57);
        put("UP",0x18); put("DOWN",0x52); put("LEFT",0x08); put("RIGHT",0x5A);
        put("OK",0x02); put("MENU",0x21); put("BACK",0x22);
        put("1",0x0C); put("2",0x18); put("3",0x5E); put("4",0x08); put("5",0x1C);
        put("6",0x5A); put("7",0x42); put("8",0x4A); put("9",0x52); put("0",0x68);
    }};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            ir = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);
        } catch (Throwable ignored) {
            ir = null;
        }
        build();
    }

    private TextView t(String s, int sp) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(sp); v.setTextColor(Color.WHITE);
        v.setGravity(Gravity.CENTER); return v;
    }

    private Button btn(String label, final String key) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(16); b.setAllCaps(false); b.setMinHeight(58);
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { send(key); }
        });
        return b;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        r.setPadding(8,4,8,4);
        return r;
    }

    private void add(LinearLayout r, View v) {
        r.addView(v, new LinearLayout.LayoutParams(0,58,1));
    }

    private void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(243,244,246));

        TextView head = t("ريموت الحافظ R4",22);
        head.setBackgroundColor(Color.rgb(16,24,40));
        head.setPadding(0,24,0,24);
        root.addView(head);

        status = new TextView(this);
        status.setTextSize(15); status.setGravity(Gravity.CENTER);
        status.setPadding(12,14,12,14);
        root.addView(status, new LinearLayout.LayoutParams(-1,70));
        updateStatus();

        ScrollView sv = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER);

        Button power = btn("⏻  تشغيل / إطفاء","POWER");
        power.setTextSize(20);
        body.addView(power,new LinearLayout.LayoutParams(-1,64));

        LinearLayout r=row();
        add(r,btn("🔇 كتم","MUTE")); add(r,btn("−  صوت","VOL-")); add(r,btn("+  صوت","VOL+")); body.addView(r);
        r=row(); add(r,btn("◀","LEFT")); add(r,btn("▲","UP")); add(r,btn("▼","DOWN")); add(r,btn("▶","RIGHT")); body.addView(r);
        r=row(); add(r,btn("OK","OK")); add(r,btn("رجوع","BACK")); add(r,btn("القائمة","MENU")); body.addView(r);

        String[] nums={"1","2","3","4","5","6","7","8","9","0"};
        for(int i=0;i<10;i+=3){
            r=row();
            for(int j=i;j<i+3 && j<10;j++) add(r,btn(nums[j],nums[j]));
            body.addView(r);
        }

        TextView note=new TextView(this);
        note.setText("أكواد ALHAFIDH R4 تجريبية. إذا لم يستجب التلفزيون، نحتاج كود الريموت الأصلي حتى نطابق الإشارة.");
        note.setTextColor(Color.DKGRAY); note.setTextSize(14); note.setGravity(Gravity.CENTER);
        note.setPadding(18,18,18,18); body.addView(note);

        sv.addView(body);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    private void updateStatus() {
        boolean has = false;
        try { has = ir != null && ir.hasIrEmitter(); } catch (Throwable ignored) {}
        if (has) {
            status.setText("✅ الـ IR موجود بالموبايل — جاهز للإرسال");
            status.setTextColor(Color.rgb(0,120,60));
        } else {
            status.setText("❌ ماكو IR Blaster ظاهر بالجهاز");
            status.setTextColor(Color.RED);
        }
        status.setBackgroundColor(Color.WHITE);
    }

    private void send(String key) {
        try {
            if (ir == null || !ir.hasIrEmitter()) {
                Toast.makeText(this,"الموبايل ما متعرف على IR Blaster",Toast.LENGTH_LONG).show();
                return;
            }
            Integer cmd = code.get(key);
            if (cmd == null) return;

            int[] pattern = nec(0x00, cmd);
            if (pattern.length < 2) {
                Toast.makeText(this,"الإشارة غير صالحة",Toast.LENGTH_LONG).show();
                return;
            }

            ir.transmit(freq, pattern);
            Toast.makeText(this,"تم إرسال " + key,Toast.LENGTH_SHORT).show();
        } catch (Throwable e) {
            String msg = e.getClass().getSimpleName();
            if (e.getMessage() != null && !e.getMessage().isEmpty()) msg += ": " + e.getMessage();
            Toast.makeText(this,"تعذر إرسال الأمر\n" + msg,Toast.LENGTH_LONG).show();
        }
    }

    private int[] nec(int address, int command) {
        int value = ((address & 0xFF) << 24)
                | ((address ^ 0xFF) & 0xFF) << 16
                | ((command & 0xFF) << 8)
                | ((command ^ 0xFF) & 0xFF);

        ArrayList<Integer> p = new ArrayList<Integer>();
        p.add(9000); p.add(4500);
        for (int i=0;i<32;i++) {
            p.add(560);
            p.add(((value & (1 << i)) != 0) ? 1690 : 560);
        }
        p.add(560);

        int[] a = new int[p.size()];
        for (int i=0;i<a.length;i++) a[i]=p.get(i);
        return a;
    }
}
