package com.hafidh.r4remote;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.hardware.ConsumerIrManager;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.graphics.drawable.GradientDrawable;
import android.widget.*;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private ConsumerIrManager ir;
    private TextView status;
    private final int freq = 38000;

    // TCL TV NEC IR codes (32-bit) from community TCL IR references.
    // These are a TCL test profile, not confirmed ALHAFIDH R4 codes.
    private final Map<String,Long> code = new HashMap<String,Long>() {{
        put("POWER", 0x57E318E7L);
        put("POWER_ON", 0x57E316E9L);
        put("POWER_OFF", 0x57E318E7L);
        put("VOL+", 0x57E3F00FL);
        put("VOL-", 0x57E308F7L);
        put("MUTE", 0x57E304FBL);
        put("UP", 0x57E39867L);
        put("DOWN", 0x57E3CC33L);
        put("LEFT", 0x57E37887L);
        put("RIGHT", 0x57E3B44BL);
        put("OK", 0x57E354ABL);
        put("BACK", 0x57E36699L);
        put("HOME", 0x57E3C03FL);
        put("HDMI1", 0x57E3847BL);
        put("HDMI2", 0x57E344BBL);
        put("HDMI3", 0x57E3C43BL);
        put("INPUT", 0x57E3748BL);
    }};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        try { ir = (ConsumerIrManager)getSystemService(Context.CONSUMER_IR_SERVICE); }
        catch (Throwable ignored) { ir = null; }
        build();
    }

    private TextView text(String s, int sp) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(sp); v.setTextColor(Color.WHITE);
        v.setGravity(Gravity.CENTER); return v;
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(radius); return g;
    }

    private TextView btn(String label, final String key, int color) {
        TextView b = text(label, 16);
        b.setTypeface(null, android.graphics.Typeface.BOLD);
        b.setPadding(5,5,5,5); b.setClickable(true); b.setFocusable(true);
        b.setBackground(bg(color, 28));
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { send(key); }
        });
        return b;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER);
        r.setPadding(8,3,8,3); return r;
    }

    private void add(LinearLayout r, View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,58,1);
        lp.setMargins(5,5,5,5); r.addView(v,lp);
    }

    private void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245,245,245));

        TextView head = text("TCL • ريموت الحافظ R4",21);
        head.setBackgroundColor(Color.rgb(24,24,24)); head.setPadding(0,20,0,20);
        root.addView(head);

        status = new TextView(this); status.setTextSize(14); status.setGravity(Gravity.CENTER);
        status.setPadding(10,12,10,12); root.addView(status,new LinearLayout.LayoutParams(-1,62));
        updateStatus();

        ScrollView sv = new ScrollView(this);
        LinearLayout body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER); body.setPadding(4,4,4,12);

        TextView power = btn("⏻", "POWER", Color.rgb(210,30,30)); power.setTextSize(28);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(88,70); pp.gravity=Gravity.CENTER; pp.setMargins(8,8,8,8);
        body.addView(power,pp);

        LinearLayout r=row(); add(r,btn("🔇","MUTE",Color.rgb(55,55,55))); add(r,btn("−","VOL-",Color.rgb(70,70,70))); add(r,btn("+","VOL+",Color.rgb(70,70,70))); body.addView(r);

        r=row(); add(r,btn("◀","LEFT",Color.rgb(65,65,65))); add(r,btn("▲","UP",Color.rgb(65,65,65))); add(r,btn("▼","DOWN",Color.rgb(65,65,65))); add(r,btn("▶","RIGHT",Color.rgb(65,65,65))); body.addView(r);
        r=row(); add(r,btn("OK","OK",Color.rgb(40,40,40))); body.addView(r);
        r=row(); add(r,btn("⌂ Home","HOME",Color.rgb(65,65,65))); add(r,btn("↩ رجوع","BACK",Color.rgb(65,65,65))); add(r,btn("Input","INPUT",Color.rgb(65,65,65))); body.addView(r);
        r=row(); add(r,btn("HDMI 1","HDMI1",Color.rgb(65,65,65))); add(r,btn("HDMI 2","HDMI2",Color.rgb(65,65,65))); add(r,btn("HDMI 3","HDMI3",Color.rgb(65,65,65))); body.addView(r);

        TextView note=text("بروفايل TCL — IR 38 kHz / NEC 32-bit\nالأكواد مأخوذة من مراجع TCL مجتمعية للاختبار فقط. إذا ما استجاب ALHAFIDH R4، نحتاج ننتقل لبروفايل IR ثاني.",13);
        note.setTextColor(Color.DKGRAY); note.setPadding(18,20,18,20); body.addView(note);

        sv.addView(body); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private void updateStatus() {
        boolean has=false; try { has=ir!=null && ir.hasIrEmitter(); } catch(Throwable ignored) {}
        status.setText(has ? "✅ IR موجود — TCL IR test profile" : "❌ ماكو IR Blaster ظاهر بالجهاز");
        status.setTextColor(has ? Color.rgb(0,120,60) : Color.RED); status.setBackgroundColor(Color.WHITE);
    }

    private void send(String key) {
        try {
            if(ir==null || !ir.hasIrEmitter()) { Toast.makeText(this,"الموبايل ما متعرف على IR Blaster",Toast.LENGTH_LONG).show(); return; }
            Long value=code.get(key); if(value==null)return;
            int[] pattern=nec32(value.longValue());
            ir.transmit(freq,pattern);
            Toast.makeText(this,"تم إرسال TCL: "+key,Toast.LENGTH_SHORT).show();
        } catch(Throwable e) {
            String msg=e.getClass().getSimpleName(); if(e.getMessage()!=null&&!e.getMessage().isEmpty())msg += ": "+e.getMessage();
            Toast.makeText(this,"تعذر إرسال الأمر\n"+msg,Toast.LENGTH_LONG).show();
        }
    }

    private int[] nec32(long value) {
        int[] p=new int[67]; int k=0;
        p[k++]=9000; p[k++]=4500;
        for(int i=0;i<32;i++) { p[k++]=560; p[k++]=((value & (1L<<i))!=0)?1690:560; }
        p[k++]=560; return p;
    }
}
