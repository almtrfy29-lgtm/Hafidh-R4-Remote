1. Create a GitHub repository.
2. Upload all files in this folder.
3. Open Actions > Build APK > Run workflow.
4. Wait for the build to finish.
5. Open the completed workflow and download the Hafidh-R4-Remote artifact.
