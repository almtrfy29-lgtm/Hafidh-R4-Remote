package com.hafidh.r4remote;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.hardware.ConsumerIrManager;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    ConsumerIrManager ir;
    TextView status;
    int freq = 38000;
    String lastError = "";

    // Generic NEC candidate codes. These are NOT confirmed Alhafidh R4 codes.
    final Map<String,Integer> code = new HashMap<String,Integer>() {{
        put("POWER",0x45); put("MUTE",0x43); put("VOL+",0x62); put("VOL-",0x57);
        put("UP",0x18); put("DOWN",0x52); put("LEFT",0x08); put("RIGHT",0x5A);
        put("OK",0x02); put("MENU",0x21); put("BACK",0x22);
        put("1",0x0C); put("2",0x18); put("3",0x5E); put("4",0x08); put("5",0x1C);
        put("6",0x5A); put("7",0x42); put("8",0x4A); put("9",0x52); put("0",0x68);
    }};

    @Override public void onCreate(Bundle b){ super.onCreate(b); ir=(ConsumerIrManager)getSystemService(CONSUMER_IR_SERVICE); build(); }

    TextView t(String s,int sp){ TextView v=new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(Color.WHITE); v.setGravity(Gravity.CENTER); return v; }
    Button btn(String label, final String key){
        Button b=new Button(this); b.setText(label); b.setTextSize(16); b.setAllCaps(false); b.setMinHeight(58);
        b.setOnClickListener(v -> send(key)); return b;
    }
    LinearLayout row(){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER); r.setPadding(8,4,8,4); return r; }
    void add(LinearLayout r, View v){ r.addView(v,new LinearLayout.LayoutParams(0,58,1)); }

    void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(243,244,246));
        TextView head=t("ريموت الحافظ R4",22); head.setBackgroundColor(Color.rgb(16,24,40)); head.setPadding(0,24,0,24); root.addView(head);
        status=new TextView(this); status.setTextSize(15); status.setGravity(Gravity.CENTER); status.setPadding(12,14,12,14);
        root.addView(status,new LinearLayout.LayoutParams(-1,70)); updateStatus();
        ScrollView sv=new ScrollView(this); LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setGravity(Gravity.CENTER);
        Button power=btn("⏻  تشغيل / إطفاء","POWER"); power.setTextSize(20); body.addView(power,new LinearLayout.LayoutParams(-1,64));
        LinearLayout r=row(); add(r,btn("🔇 كتم","MUTE")); add(r,btn("−  صوت","VOL-")); add(r,btn("+  صوت","VOL+")); body.addView(r);
        r=row(); add(r,btn("◀","LEFT")); add(r,btn("▲","UP")); add(r,btn("▼","DOWN")); add(r,btn("▶","RIGHT")); body.addView(r);
        r=row(); add(r,btn("OK","OK")); add(r,btn("رجوع","BACK")); add(r,btn("القائمة","MENU")); body.addView(r);
        String[] nums={"1","2","3","4","5","6","7","8","9","0"};
        for(int i=0;i<10;i+=3){ r=row(); for(int j=i;j<i+3 && j<10;j++) add(r,btn(nums[j],nums[j])); body.addView(r); }
        TextView note=new TextView(this); note.setText("ملاحظة: هذا الإصدار يستخدم أكواد NEC تجريبية. أكواد ALHAFIDH R4 الأصلية غير مؤكدة بعد. إذا لم يستجب التلفزيون، نغيّر مجموعة الأكواد."); note.setTextColor(Color.DKGRAY); note.setTextSize(14); note.setGravity(Gravity.CENTER); note.setPadding(18,18,18,18); body.addView(note);
        sv.addView(body); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    void updateStatus(){
        boolean has=ir!=null && ir.hasIrEmitter();
        status.setText(has?"✅ الـ IR موجود بالموبايل — جاهز للإرسال":"❌ ماكو IR Blaster ظاهر بالجهاز");
        status.setTextColor(has?Color.rgb(0,120,60):Color.RED); status.setBackgroundColor(Color.WHITE);
    }
    void send(String key){
        if(ir==null || !ir.hasIrEmitter()){
            Toast.makeText(this,"الموبايل ما متعرف على IR Blaster",Toast.LENGTH_LONG).show();
            return;
        }
        Integer cmd=code.get(key);
        if(cmd==null)return;
        try {
            freq = getSafeFrequency();
            int address=0x00; // generic NEC address candidate
            int value=(address<<24)|((address^0xFF)<<16)|(cmd<<8)|(cmd^0xFF);
            int[] p=nec(value);
            ir.transmit(freq,p);
            Toast.makeText(this,"تم إرسال "+key+" — "+freq+" Hz",Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            lastError = e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage());
            Toast.makeText(this,"تعذر إرسال الأمر: "+lastError,Toast.LENGTH_LONG).show();
        }
    }

    int getSafeFrequency(){
        try {
            android.hardware.ConsumerIrManager.CarrierFrequencyRange[] ranges = ir.getCarrierFrequencies();
            if(ranges != null && ranges.length > 0){
                for(android.hardware.ConsumerIrManager.CarrierFrequencyRange r : ranges){
                    if(38000 >= r.getMinFrequency() && 38000 <= r.getMaxFrequency()) return 38000;
                }
                return (ranges[0].getMinFrequency()+ranges[0].getMaxFrequency())/2;
            }
        } catch(Exception ignored) {}
        return 38000;
    }
    int[] nec(int value){
        ArrayList<Integer> p=new ArrayList<>(); p.add(9000); p.add(4500);
        for(int i=0;i<32;i++){ p.add(560); p.add(((value & (1<<i))!=0)?1690:560); }
        p.add(560); int[] a=new int[p.size()]; for(int i=0;i<a.length;i++)a[i]=p.get(i); return a;
    }
}
